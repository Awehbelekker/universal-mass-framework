from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import secrets
from core.project_importer import ProjectImporter
from core.plugin_manager import PluginManager
from core.persistent_memory import PersistentMemory
from core.mass_coordinator import MASSCoordinator
from core.websocket_manager import manager
from core.workflow_engine import WorkflowEngine, WORKFLOW_TEMPLATES
from agents.ai_agents import CodeGeneratorAgent, AIDocumentationAgent, AITestingAgent, AIDebuggingAgent
from agents.ai_agents.sample_agents import CodeAnalyzerAgent, DocumentationAgent, TestingAgent
# Authentication imports
from core.auth_service import (
    User, 
    UserRole, 
    Permission, 
    LoginCredentials, 
    AuthToken,
    create_default_admin,
    login,
    verify_token
)
import os
import json
import asyncio
import logging
from datetime import datetime, timezone
from agents.ai_agents.core import setup_logging
from agents.ai_agents.integrations import WeatherAgent
from agents.ai_agents.types import DataFetcherAgent, DecisionAgent
from agents.ai_agents.raft import RaftAgent
from agents.ai_agents.distributed import DistributedCoordinator
from core.analytics import AnalyticsManager
from core.audit_log import AuditLogManager
from core.multi_tenancy import TenantManager
from core.monitoring import monitoring_router
import sys
from fastapi import Request

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app(auth_service: Any, db_manager: Any) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Application lifespan manager"""
        # Startup
        try:
            # Only create default admin if not running under pytest
            if not ("PYTEST_CURRENT_TEST" in os.environ):
                create_default_admin()
            logger.info("Application startup completed")
            yield
        except Exception as e:
            logger.error(f"Startup failed: {str(e)}")
            raise
        finally:
            # Shutdown
            logger.info("Application shutdown")
            pass

    app = FastAPI(
        title="AI Development MASS Framework", 
        version="2.0.0",
        lifespan=lifespan
    )
    app.state.auth_service = auth_service
    app.state.db_manager = db_manager
    
    # Initialize and inject collaboration manager and sample agents
    from core.agent_collaboration_manager import collaboration_manager
    from agents.ai_agents.sample_agents import CodeAnalyzerAgent, DocumentationAgent, TestingAgent
    from agents.ai_agents.project_analysis_agent import ProjectAnalysisAgent
    from agents.ai_agents.intelligent_code_suggestion_engine import IntelligentCodeSuggestionEngine
    
    sample_agents = {
        "code_analyzer": CodeAnalyzerAgent(),
        "documentation_agent": DocumentationAgent(),
        "testing_agent": TestingAgent(),
        "ai_project_analyzer": ProjectAnalysisAgent(),
        "ai_code_suggestion_engine": IntelligentCodeSuggestionEngine()
    }
    
    app.state.collaboration_manager = collaboration_manager
    app.state.sample_agents = sample_agents

    # Security scheme
    security = HTTPBearer()

    # Add CORS middleware for frontend integration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3000", "http://localhost:3001"],  # React dev server
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include monitoring router
    app.include_router(monitoring_router)
    
    # Authentication helper functions
    def get_auth_service(request: Request) -> Any:
        return request.app.state.auth_service
    
    def get_db_manager(request: Request) -> Any:
        return request.app.state.db_manager
    
    def get_current_user_from_token(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        auth_service=Depends(get_auth_service)
    ) -> User:
        token_payload = auth_service.verify_token(credentials.credentials)
        if not token_payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        user = auth_service.get_user_by_id(token_payload['user_id'])
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return user

    def get_current_user_from_api_key(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        auth_service=Depends(get_auth_service)
    ) -> Dict[str, Any]:
        api_key_info = auth_service.verify_api_key(credentials.credentials)
        if not api_key_info:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid API key",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return api_key_info

    def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        auth_service=Depends(get_auth_service)
    ) -> User:
        try:
            return get_current_user_from_token(credentials, auth_service)
        except HTTPException:
            api_key_info = get_current_user_from_api_key(credentials, auth_service)
            user = auth_service.get_user_by_id(api_key_info['user_id'])
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            return user

    def require_permission(permission: Permission):
        def permission_checker(
            current_user: User = Depends(get_current_user),
            auth_service=Depends(get_auth_service)
        ):
            if not auth_service.has_permission(current_user, permission):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission denied: {permission.value}"
                )
            return current_user
        return permission_checker

    # Initialize sample agents
    # Add AI agents to sample agents
    from agents.ai_agents.code_generator_agent import CodeGeneratorAgent
    from agents.ai_agents.documentation_agent import AIDocumentationAgent
    from agents.ai_agents.testing_agent import AITestingAgent
    from agents.ai_agents.debugging_agent import AIDebuggingAgent
    from agents.ai_agents.project_analysis_agent import ProjectAnalysisAgent
    from agents.ai_agents.intelligent_code_suggestion_engine import IntelligentCodeSuggestionEngine

    sample_agents = {
        "code_analyzer": CodeAnalyzerAgent(),
        "documentation_agent": DocumentationAgent(), 
        "testing_agent": TestingAgent(),
        "ai_code_generator": CodeGeneratorAgent(),
        "ai_documentation_agent": AIDocumentationAgent(),
        "ai_testing_agent": AITestingAgent(),
        "ai_debugging_agent": AIDebuggingAgent(),
        "ai_project_analyzer": ProjectAnalysisAgent(),
        "ai_code_suggestion_engine": IntelligentCodeSuggestionEngine()
    }

    # Initialize workflow engine
    workflow_engine = WorkflowEngine(sample_agents)

    # Initialize AI coordinator and collaboration manager (after MASSCoordinator is created)
    from core.ai_coordinator import get_ai_coordinator
    from core.agent_collaboration_manager import collaboration_manager
    # AI coordinator will be initialized after MASSCoordinator is created below

    # Authentication Pydantic models
    class LoginRequest(BaseModel):
        username: str
        password: str
        tenant_id: Optional[str] = None

    class LoginResponse(BaseModel):
        access_token: str
        token_type: str = "bearer"
        expires_in: int
        user: Dict[str, Any]

    class CreateUserRequest(BaseModel):
        username: str
        email: str
        password: str
        role: str
        tenant_id: str = "default"
        metadata: Optional[Dict[str, Any]] = None

    class UserResponse(BaseModel):
        id: str
        username: str
        email: str
        role: str
        tenant_id: str
        is_active: bool
        created_at: Optional[str] = None
        last_login: Optional[str] = None

    class CreateAPIKeyRequest(BaseModel):
        name: str
        permissions: Optional[List[str]] = None
        expires_at: Optional[str] = None

    class APIKeyResponse(BaseModel):
        api_key: str
        name: str
        permissions: List[str]
        expires_at: Optional[str] = None

    class UpdateRoleRequest(BaseModel):
        role: str

    # Pydantic models for request/response
    class AgentTask(BaseModel):
        id: str
        name: str
        description: str
        status: str = "pending"
        priority: int = 1
        assigned_agent: Optional[str] = None

    class WorkflowRequest(BaseModel):
        name: str
        tasks: List[AgentTask]
        project_path: Optional[str] = None

    class AgentStatus(BaseModel):
        agent_id: str
        name: str
        status: str
        current_task: Optional[str] = None
        last_update: str

    # Global coordinator instance
    coordinator = MASSCoordinator()

    # Initialize AI coordinator after MASSCoordinator is created
    ai_coordinator = get_ai_coordinator(coordinator)

    # Register agents with collaboration manager
    for agent_id, agent in sample_agents.items():
        collaboration_manager.register_agent(agent)    # WebSocket endpoint for real-time updates
    @app.websocket("/ws/{client_id}")
    async def websocket_endpoint(websocket: WebSocket, client_id: str):
        await manager.connect(websocket, client_id)
        try:
            while True:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                # Handle different message types
                if message.get("type") == "ping":
                    await manager.send_personal_message(
                        json.dumps({"type": "pong", "timestamp": "2025-06-14T08:00:00Z"}),
                        websocket
                    )
                elif message.get("type") == "request_status":
                    await manager.broadcast_system_status()
        except WebSocketDisconnect:
            manager.disconnect(websocket)
            await manager.broadcast_system_status()    @app.get("/")
    async def root() -> FileResponse:
        return FileResponse('frontend/index.html')

    # ==================== AUTHENTICATION ENDPOINTS ====================

    @app.post("/auth/login", response_model=LoginResponse)
    async def login_endpoint(login_request: LoginRequest) -> LoginResponse:
        """Authenticate user and return JWT token"""
        try:
            credentials = LoginCredentials(
                username=login_request.username,
                password=login_request.password,
                tenant_id=login_request.tenant_id
            )
            user = auth_service.authenticate_user(credentials)
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid credentials"
                )
            auth_token = auth_service.generate_token(user)
            return LoginResponse(
                access_token=auth_token.token,
                expires_in=auth_service.token_expiry_hours * 3600,
                user={
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "role": user.role.value,
                    "tenant_id": user.tenant_id
                }
            )
        except Exception as e:
            import traceback
            print(f"[DEBUG] /auth/login: Exception: {e}\n{traceback.format_exc()}", file=sys.stderr)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Login failed"
            )

    @app.post("/auth/logout")
    async def logout_endpoint(current_user: User = Depends(get_current_user)) -> Dict[str, str]:
        """Logout user and revoke token"""
        try:
            # Note: In a real implementation, you'd get the token from the request
            # For now, we'll just deactivate all user sessions
            auth_service.db_manager.execute_query(
                "UPDATE user_sessions SET is_active = FALSE WHERE user_id = ?",
                (current_user.id,)
            )
            
            return {"message": "Logout successful"}
            
        except Exception as e:
            logger.error(f"Logout failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Logout failed"
            )

    @app.get("/auth/me", response_model=UserResponse)
    async def get_current_user_info(current_user: User = Depends(get_current_user)):
        """Get current user information"""
        return UserResponse(
            id=current_user.id,
            username=current_user.username,
            email=current_user.email,
            role=current_user.role.value,
            tenant_id=current_user.tenant_id,
            is_active=current_user.is_active,
            created_at=current_user.created_at.isoformat() if current_user.created_at else None,
            last_login=current_user.last_login.isoformat() if current_user.last_login else None
        )

    @app.post("/auth/users", response_model=UserResponse)
    async def create_user_endpoint(
        user_request: CreateUserRequest,
        admin_user: User = Depends(require_permission(Permission.MANAGE_USERS))
    ):
        """Create a new user (admin only)"""
        try:
            # Validate role
            try:
                role = UserRole(user_request.role)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid role: {user_request.role}"
                )
            
            user = auth_service.create_user(
                username=user_request.username,
                email=user_request.email,
                password=user_request.password,
                role=role,
                tenant_id=user_request.tenant_id,
                metadata=user_request.metadata
            )
            # Explicitly commit the transaction to ensure visibility across connections
            if hasattr(auth_service, 'db_manager') and hasattr(auth_service.db_manager, '_external_connection'):
                conn = auth_service.db_manager._external_connection
                if conn is not None:
                    conn.commit()
            elif hasattr(auth_service.db_manager, 'connection') and auth_service.db_manager.connection is not None:
                auth_service.db_manager.connection.commit()
            
            return UserResponse(
                id=user.id,
                username=user.username,
                email=user.email,
                role=user.role.value,
                tenant_id=user.tenant_id,
                is_active=user.is_active,
                created_at=user.created_at.isoformat() if user.created_at else None
            )
            
        except Exception as e:
            logger.error(f"User creation failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="User creation failed"
            )

    @app.get("/users")
    async def list_users(current_user: User = Depends(get_current_user)):
        """List all users."""
        users = auth_service.get_all_users()
        return [
            {
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "role": u.role.value,
                "tenant_id": u.tenant_id
            } for u in users
        ]

    @app.post("/users/{user_id}/role")
    async def update_user_role(user_id: str, new_role: str, current_user: User = Depends(get_current_user)):
        """Update a user's role."""
        user = auth_service.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        old_role = user.role.value
        auth_service.update_user_role(user_id, new_role)
        audit_log_manager.log_event(current_user.id, "update_user_role", {"user_id": user_id, "old_role": old_role, "new_role": new_role}, current_user.tenant_id)
        return {"status": "ok"}

    @app.put("/auth/users/{user_id}/role")
    async def update_user_role_endpoint(
        user_id: str,
        role_request: UpdateRoleRequest,
        admin_user: User = Depends(require_permission(Permission.MANAGE_USERS))
    ):
        """Update user role (admin only)"""
        try:
            # Validate role
            try:
                new_role = UserRole(role_request.role)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid role: {role_request.role}"
                )
            
            success = auth_service.update_user_role(user_id, new_role, admin_user)
            
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found or update failed"
                )
            
            return {"message": f"User role updated to {new_role.value}"}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Role update failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Role update failed"
            )

    @app.delete("/auth/users/{user_id}")
    async def deactivate_user_endpoint(
        user_id: str,
        admin_user: User = Depends(require_permission(Permission.MANAGE_USERS))
    ):
        """Deactivate a user (admin only)"""
        try:
            success = auth_service.deactivate_user(user_id, admin_user)
            
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found or deactivation failed"
                )
            
            return {"message": "User deactivated successfully"}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"User deactivation failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="User deactivation failed"
            )

    @app.post("/auth/api-keys", response_model=APIKeyResponse)
    async def create_api_key_endpoint(
        api_key_request: CreateAPIKeyRequest,
        current_user: User = Depends(get_current_user)
    ):
        """Create an API key for the current user"""
        try:
            # Parse permissions if provided
            permissions = []
            if api_key_request.permissions:
                for perm_str in api_key_request.permissions:
                    try:
                        permissions.append(Permission(perm_str))
                    except ValueError:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"Invalid permission: {perm_str}"
                        )
            
            # Parse expiration date if provided
            expires_at = None
            if api_key_request.expires_at:
                try:
                    expires_at = datetime.fromisoformat(api_key_request.expires_at)
                except ValueError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid expiration date format"
                    )
            
            api_key = auth_service.create_api_key(
                user=current_user,
                name=api_key_request.name,
                permissions=permissions or None,
                expires_at=expires_at
            )
            
            return APIKeyResponse(
                api_key=api_key,
                name=api_key_request.name,
                permissions=[p.value for p in (permissions or auth_service.get_user_permissions(current_user))],
                expires_at=expires_at.isoformat() if expires_at else None
            )
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"API key creation failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="API key creation failed"
            )

    @app.get("/auth/stats")
    async def get_auth_stats_endpoint(
        admin_user: User = Depends(require_permission(Permission.VIEW_ANALYTICS))
    ):
        """Get authentication statistics (admin only)"""
        try:
            stats = auth_service.get_auth_stats(admin_user)
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get auth stats: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to get authentication statistics"
            )

    # ==================== END AUTHENTICATION ENDPOINTS ====================    @app.post("/import-project/")
    async def import_project(file: UploadFile = File(...)) -> Dict[str, Any]:
        # Save uploaded zip and extract
        upload_dir = "uploaded_projects"
        os.makedirs(upload_dir, exist_ok=True)
        zip_path = os.path.join(upload_dir, file.filename)
        with open(zip_path, "wb") as f:
            f.write(await file.read())
        # Extraction logic would go here
        # For now, just return file info        return {"filename": file.filename, "status": "uploaded"}

    @app.get("/plugins/")
    def list_plugins():
        pm = PluginManager('agents.research')
        pm.discover_plugins()
        return {"plugins": list(pm.plugins.keys())}

    @app.get("/memory/{key}")
    def get_memory(key: str) -> Dict[str, Any]:
        mem = PersistentMemory()
        return {"key": key, "value": mem.get(key)}

    @app.post("/memory/{key}")
    def set_memory(key: str, value: str):
        mem = PersistentMemory()
        mem.set(key, value)
        return {"key": key, "value": value}

    # Project Management Endpoints
    @app.post("/projects/analyze/")
    async def analyze_project(project_path: str):
        """Analyze a project and suggest agent tasks"""
        try:
            importer = ProjectImporter('.')
            project_data = importer.import_project(project_path)
            
            # Generate suggested tasks based on project structure
            suggested_tasks = []
            if any('.py' in f for f in project_data['files']):
                suggested_tasks.append({
                    "id": "python_analysis",
                    "name": "Python Code Analysis",
                    "description": "Analyze Python code for best practices and improvements",
                    "priority": 2
                })
            if any('.js' in f or '.ts' in f for f in project_data['files']):
                suggested_tasks.append({
                    "id": "js_analysis", 
                    "name": "JavaScript/TypeScript Analysis",
                    "description": "Analyze JS/TS code for optimization opportunities",
                    "priority": 2
                })
            if any('requirements.txt' in f or 'package.json' in f for f in project_data['files']):
                suggested_tasks.append({
                    "id": "dependency_audit",
                    "name": "Dependency Security Audit", 
                    "description": "Check dependencies for security vulnerabilities",
                    "priority": 3
                })
            
            return {
                "project_structure": project_data,
                "suggested_tasks": suggested_tasks,
                "analysis_complete": True
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    # Agent Management Endpoints
    @app.get("/agents/")
    async def list_agents():
        """Get list of available agents and their status"""
        pm = PluginManager('agents')
        pm.discover_plugins()
        
        agents = []
        for agent_id, agent_class in pm.plugins.items():
            agents.append({
                "id": agent_id,
                "name": agent_class.__name__ if hasattr(agent_class, '__name__') else agent_id,
                "status": "available",
                "capabilities": getattr(agent_class, 'capabilities', []),
                "description": getattr(agent_class, '__doc__', 'No description available')
            })
        
        return {"agents": agents, "total": len(agents)}

    @app.post("/agents/{agent_id}/activate")
    async def activate_agent(agent_id: str):
        """Activate a specific agent"""
        try:
            # In a real implementation, this would start the agent process
            return {"agent_id": agent_id, "status": "activated", "message": "Agent activated successfully"}
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.get("/agents/{agent_id}/status")
    async def get_agent_status(agent_id: str):
        """Get detailed status of a specific agent"""
        # Mock status for now - in real implementation would query actual agent
        return {
            "agent_id": agent_id,
            "status": "idle",
            "current_task": None,
            "completed_tasks": 0,
            "uptime": "0:00:00",
            "last_heartbeat": "2025-06-14T12:00:00Z"
        }

    # Agent execution endpoint
    @app.post("/api/agents/{agent_id}/execute")
    async def execute_agent_task(agent_id: str, task: Dict[str, Any]):
        """Execute a task with a specific agent"""
        if agent_id in sample_agents:
            agent = sample_agents[agent_id]
            try:
                # Execute the task
                result = await agent.process_task(task)
                
                # Broadcast update via WebSocket
                await manager.broadcast_agent_update(
                    agent_id, "completed", f"Task completed: {task.get('type', 'unknown')}"
                )
                
                return {
                    "agent_id": agent_id,
                    "task_type": task.get("type", "unknown"),
                    "status": "completed",
                    "result": result,
                    "timestamp": "2025-06-14T08:00:00Z"
                }
            except Exception as e:
                # Broadcast error via WebSocket
                await manager.broadcast_agent_update(
                    agent_id, "error", f"Task failed: {str(e)}"
                )
                raise HTTPException(status_code=500, detail=f"Agent execution failed: {str(e)}")
        else:
            available_agents = list(sample_agents.keys())
            raise HTTPException(
                status_code=404, 
                detail=f"Agent '{agent_id}' not found. Available agents: {available_agents}"
            )

    @app.get("/api/agents/{agent_id}/status")
    async def get_agent_status(agent_id: str):
        """Get the current status of a specific agent"""
        if agent_id in sample_agents:
            agent = sample_agents[agent_id]
            return {
                "agent_id": agent_id,
                "name": agent.specialization,
                "status": "active",
                "capabilities": getattr(agent, 'supported_languages', []) if hasattr(agent, 'supported_languages') else [],
                "last_activity": "2025-06-14T08:00:00Z",
                "message_queue_size": len(agent.message_queue)
            }
        else:
            raise HTTPException(status_code=404, detail="Agent not found")

    # Workflow Management Endpoints
    @app.post("/workflows/")
    async def create_workflow(workflow: WorkflowRequest):
        """Create and execute a new workflow"""
        try:
            workflow_id = f"workflow_{len(workflow.tasks)}_{workflow.name.replace(' ', '_')}"
            
            # Store workflow in coordinator
            workflow_data = {
                "id": workflow_id,
                "name": workflow.name,
                "tasks": [task.dict() for task in workflow.tasks],
                "status": "created",
                "project_path": workflow.project_path
            }
            
            # In real implementation, would pass to coordinator for execution
            mem = PersistentMemory()
            mem.set(f"workflow_{workflow_id}", json.dumps(workflow_data))
            
            return {"workflow_id": workflow_id, "status": "created", "task_count": len(workflow.tasks)}
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.get("/workflows/")
    async def list_workflows():
        """Get list of all workflows"""
        mem = PersistentMemory()
        workflows = []
        
        # In real implementation, would have proper workflow storage
        # For now, return mock data
        workflows.append({
            "id": "workflow_demo",
            "name": "Demo Workflow", 
            "status": "completed",
            "task_count": 3,
            "created_at": "2025-06-14T12:00:00Z"
        })
        
        return {"workflows": workflows, "total": len(workflows)}

    @app.get("/workflows/{workflow_id}")
    async def get_workflow(workflow_id: str):
        """Get detailed information about a specific workflow"""
        mem = PersistentMemory()
        workflow_data = mem.get(f"workflow_{workflow_id}")
        
        if workflow_data:
            return json.loads(workflow_data)
        else:
            raise HTTPException(status_code=404, detail="Workflow not found")

    # Workflow management endpoints
    @app.post("/api/workflows/create")
    async def create_workflow(workflow_request: Dict[str, Any]):
        """Create a new workflow from configuration"""
        try:
            workflow_id = workflow_engine.create_workflow(
                name=workflow_request["name"],
                description=workflow_request.get("description", ""),
                steps_config=workflow_request["steps"]
            )
            
            # Broadcast workflow creation
            await manager.broadcast(json.dumps({
                "type": "workflow_created",
                "data": {"workflow_id": workflow_id, "name": workflow_request["name"]}
            }))
            
            return {
                "workflow_id": workflow_id,
                "status": "created",
                "message": "Workflow created successfully"
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to create workflow: {str(e)}")

    @app.post("/api/workflows/{workflow_id}/execute")
    async def execute_workflow(workflow_id: str):
        """Execute a workflow asynchronously"""
        try:
            # Start workflow execution in background
            asyncio.create_task(workflow_engine.execute_workflow(workflow_id))
            
            # Broadcast workflow start
            await manager.broadcast(json.dumps({
                "type": "workflow_started",
                "data": {"workflow_id": workflow_id}
            }))
            
            return {
                "workflow_id": workflow_id,
                "status": "started",
                "message": "Workflow execution started"
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to execute workflow: {str(e)}")

    @app.get("/api/workflows")
    async def list_workflows():
        """List all workflows"""
        workflows = workflow_engine.list_workflows()
        return {"workflows": workflows, "total": len(workflows)}

    @app.get("/api/workflows/{workflow_id}")
    async def get_workflow_status(workflow_id: str):
        """Get detailed workflow status"""
        try:
            status = workflow_engine.get_workflow_status(workflow_id)
            return status
        except ValueError as e:
            raise HTTPException(status_code=404, detail=str(e))

    @app.post("/api/workflows/{workflow_id}/cancel")
    async def cancel_workflow(workflow_id: str):
        """Cancel a running workflow"""
        try:
            success = await workflow_engine.cancel_workflow(workflow_id)
            if success:
                # Broadcast workflow cancellation
                await manager.broadcast(json.dumps({
                    "type": "workflow_cancelled",
                    "data": {"workflow_id": workflow_id}
                }))
                return {"workflow_id": workflow_id, "status": "cancelled"}
            else:
                raise HTTPException(status_code=400, detail="Workflow could not be cancelled")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to cancel workflow: {str(e)}")

    @app.post("/api/workflows/{workflow_id}/pause")
    async def pause_workflow(workflow_id: str):
        """Pause a running workflow"""
        try:
            success = await workflow_engine.pause_workflow(workflow_id)
            if success:
                # Broadcast workflow pause
                await manager.broadcast(json.dumps({
                    "type": "workflow_paused",
                    "data": {"workflow_id": workflow_id}
                }))
                return {"workflow_id": workflow_id, "status": "paused"}
            else:
                raise HTTPException(status_code=400, detail="Workflow could not be paused")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to pause workflow: {str(e)}")

    @app.post("/api/workflows/{workflow_id}/resume")
    async def resume_workflow(workflow_id: str):
        """Resume a paused workflow"""
        try:
            success = await workflow_engine.resume_workflow(workflow_id)
            if success:
                # Broadcast workflow resume
                await manager.broadcast(json.dumps({
                    "type": "workflow_resumed",
                    "data": {"workflow_id": workflow_id}
                }))
                return {"workflow_id": workflow_id, "status": "resumed"}
            else:
                raise HTTPException(status_code=400, detail="Workflow could not be resumed")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to resume workflow: {str(e)}")

    @app.get("/api/workflow-templates")
    async def get_workflow_templates():
        """Get available workflow templates"""
        return {
            "templates": WORKFLOW_TEMPLATES,
            "total": len(WORKFLOW_TEMPLATES)
        }

    @app.post("/api/workflows/from-template/{template_name}")
    async def create_workflow_from_template(template_name: str, params: Dict[str, Any] = None):
        """Create a workflow from a predefined template"""
        if template_name not in WORKFLOW_TEMPLATES:
            raise HTTPException(status_code=404, detail=f"Template '{template_name}' not found")
        
        template = WORKFLOW_TEMPLATES[template_name]
        
        # Apply parameters to template if provided
        steps = template["steps"].copy()
        if params:
            for step in steps:
                step["task_params"].update(params.get("task_params", {}))
        
        try:
            workflow_id = workflow_engine.create_workflow(
                name=f"{template['name']} - {datetime.now().strftime('%Y%m%d-%H%M%S')}",
                description=template["description"],
                steps_config=steps
            )
            
            return {
                "workflow_id": workflow_id,
                "template": template_name,
                "status": "created"
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to create workflow from template: {str(e)}")

    # System Status Endpoints
    @app.get("/status/")
    async def system_status():
        """Get overall system status"""
        pm = PluginManager('agents')
        pm.discover_plugins()
        
        return {
            "system": "online",
            "version": "1.0.0",
            "agents_available": len(pm.plugins),
            "active_workflows": 0,  # Would query actual workflows
            "memory_usage": "12MB",  # Would get actual memory usage
            "uptime": "1:23:45"
        }

    # =====================================
    # AI-POWERED ENDPOINTS
    # =====================================

    from core.llm_service import llm_service
    from config.ai_config import ai_config_manager

    # AI Chat Interface
    @app.post("/api/ai/chat")
    async def ai_chat(request: Dict[str, Any]):
        """AI chat interface for natural language interaction"""
        try:
            user_message = request.get("message", "")
            conversation_history = request.get("conversation_history", [])
            
            if not user_message:
                raise HTTPException(status_code=422, detail="Message is required")
            try:
                # Use AI coordinator for chat
                response = await ai_coordinator.chat_interface(user_message, conversation_history)
            except Exception as llm_exc:
                logger.error(f"LLM service error in chat: {llm_exc}")
                raise HTTPException(status_code=503, detail=f"LLM service unavailable: {str(llm_exc)}")
            
            # Check if response contains workflow suggestions
            workflow_suggestion = None
            if "workflow" in user_message.lower() or "create" in user_message.lower():
                # Analyze if user wants to create a workflow
                try:
                    workflow_data = await ai_coordinator.create_intelligent_workflow(user_message)
                    workflow_suggestion = workflow_data
                except Exception as e:
                    logger.warning(f"Workflow suggestion error: {e}")
            # Generate basic suggestions based on user message
            suggestions = []
            if "code" in user_message.lower() or "generate" in user_message.lower():
                suggestions.append("Generate code")
            if "test" in user_message.lower():
                suggestions.append("Create tests")
            if "document" in user_message.lower() or "doc" in user_message.lower():
                suggestions.append("Write documentation")
            if "help" in user_message.lower() or "what" in user_message.lower():
                suggestions.extend(["Generate code", "Create tests", "Write documentation"])
            
            return {
                "status": "success",
                "response": response,
                "conversation_id": f"chat_{secrets.token_urlsafe(8)}",
                "type": "text",
                "workflow_suggestion": workflow_suggestion,
                "timestamp": datetime.now().isoformat(),
                "suggestions": suggestions
            }
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"AI chat failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"AI chat failed: {str(e)}")

    # AI Code Generation
    @app.post("/api/ai/generate-code")
    async def generate_code(request: Dict[str, Any]):
        """Generate code using AI"""
        try:
            description = request.get("description", "")
            language = request.get("language", "python")
            template_type = request.get("template", "function")
            if not description:
                raise HTTPException(status_code=422, detail="Code description is required")
            ai_agent = sample_agents["ai_code_generator"]
            task = {
                "type": "generate_code",
                "description": description,
                "language": language,
                "template": template_type
            }
            try:
                result = await ai_agent.process_task(task)
            except Exception as llm_exc:
                logger.error(f"LLM service error in code generation: {llm_exc}")
                raise HTTPException(status_code=503, detail=f"LLM service unavailable: {str(llm_exc)}")
            if isinstance(result, dict) and "status" not in result:
                result["status"] = "success" if "error" not in result else "error"
            await manager.broadcast(json.dumps({
                "type": "code_generated",
                "data": {
                    "language": language,
                    "template": template_type,
                    "success": "error" not in result
                }
            }))
            return result
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Code generation failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Code generation failed: {str(e)}")

    # AI Code Review
    @app.post("/api/ai/review-code")
    async def review_code(request: Dict[str, Any]):
        """Review code using AI"""
        try:
            code = request.get("code", "")
            language = request.get("language", "python")
            review_type = request.get("review_type", "comprehensive")
            
            if not code:
                raise HTTPException(status_code=400, detail="Code to review is required")
            
            ai_agent = sample_agents["ai_code_generator"]
            task = {
                "type": "review_code",
                "code": code,
                "language": language,
                "review_type": review_type
            }
            
            result = await ai_agent.process_task(task)
            
            return result
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Code review failed: {str(e)}")

    # AI Task Analysis
    @app.post("/api/ai/analyze-task")
    async def analyze_task(request: Dict[str, Any]):
        """Analyze task requirements using AI"""
        try:
            task_description = request.get("description", "")
            context = request.get("context", {})
            
            if not task_description:
                raise HTTPException(status_code=400, detail="Task description is required")
            
            # Use AI coordinator for task analysis
            analysis = await ai_coordinator.analyze_task_intelligence(task_description, context)
            
            return {
                "category": analysis.category.value,
                "complexity": analysis.complexity.value,
                "estimated_time_minutes": analysis.estimated_time_minutes,
                "required_agents": analysis.required_agents,
                "optional_agents": analysis.optional_agents,
                "risk_level": analysis.risk_level,
                "success_probability": analysis.success_probability,
                "resource_requirements": analysis.resource_requirements
            }
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Task analysis failed: {str(e)}")

    # AI Workflow Creation
    @app.post("/api/ai/create-workflow")
    async def create_ai_workflow(request: Dict[str, Any]):
        """Create intelligent workflow using AI"""
        try:
            task_description = request.get("description", "")
            context = request.get("context", {})
            
            if not task_description:
                raise HTTPException(status_code=400, detail="Task description is required")
            
            # Create intelligent workflow
            workflow_data = await ai_coordinator.create_intelligent_workflow(task_description, context)
            
            # Create the workflow in the workflow engine
            workflow_id = workflow_engine.create_workflow(
                name=workflow_data["name"],
                description=workflow_data["description"],
                steps_config=workflow_data["steps"]
            )
            
            # Broadcast workflow creation
            await manager.broadcast(json.dumps({
                "type": "ai_workflow_created",
                "data": {
                    "workflow_id": workflow_id,
                    "name": workflow_data["name"],
                    "ai_analysis": workflow_data.get("ai_analysis", {})
                }
            }))
            
            return {
                "workflow_id": workflow_id,
                "workflow_data": workflow_data,
                "status": "created",
                "message": "AI workflow created successfully"
            }
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"AI workflow creation failed: {str(e)}")

    # AI Agent Recommendations
    @app.post("/api/ai/recommend-agents")
    async def recommend_agents(request: Dict[str, Any]):
        """Get AI recommendations for agent selection"""
        try:
            task_description = request.get("task_description") or request.get("description", "")
            available_agents = list(sample_agents.keys())
            
            if not task_description:
                raise HTTPException(status_code=400, detail="Task description is required")
              # Analyze task first
            task_analysis = await ai_coordinator.analyze_task_intelligence(task_description)
            
            # Get agent recommendations
            recommendations = await ai_coordinator.recommend_agents(task_analysis, available_agents)
            
            return {
                "status": "success",
                "recommended_agents": [
                    {
                        "agent_id": rec.agent_id,
                        "confidence": rec.confidence_score,
                        "reason": rec.reasoning
                    }
                    for rec in recommendations
                ],
                "task_analysis": {
                    "category": task_analysis.category.value,
                    "complexity": task_analysis.complexity.value,
                    "risk_level": task_analysis.risk_level
                },
                "recommendations": [
                    {
                        "agent_id": rec.agent_id,
                        "confidence_score": rec.confidence_score,
                        "reasoning": rec.reasoning,
                        "estimated_contribution": rec.estimated_contribution
                    }
                    for rec in recommendations
                ]
            }
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Agent recommendation failed: {str(e)}")

    # AI Usage Statistics
    @app.get("/api/ai/usage-stats")
    async def get_ai_usage_stats():
        """Get AI usage statistics"""
        try:
            llm_stats = llm_service.get_usage_stats()
            performance_insights = await ai_coordinator.get_agent_performance_insights()        
            return {
                "status": "success",
                "usage_stats": llm_stats,
                "llm_usage": llm_stats,
                "performance_insights": performance_insights,
                "available_models": llm_service.get_available_models(),
                "total_ai_requests": llm_stats.get("total_requests", 0),
                "total_cost": llm_stats.get("total_cost", 0.0)
            }
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to get usage stats: {str(e)}")

    # AI Model Information
    @app.get("/api/ai/models")
    async def get_ai_models():
        """Get available AI models and their information"""
        try:
            models = llm_service.get_available_models()
            model_info = {}
            providers = set()
            
            for model in models:
                info = llm_service.get_model_info(model)
                if info:
                    model_info[model] = info
                    providers.add(info.get("provider", "unknown"))
            
            # Add providers to available models for backward compatibility
            available_models = models + list(providers)
            
            return {
                "status": "success",
                "models": available_models,
                "available_models": available_models,
                "model_details": model_info,
                "providers": list(providers),
                "default_models": {
                    "code_generation": ai_config_manager.config.code_generation_model,
                    "code_review": ai_config_manager.config.code_review_model,
                    "documentation": ai_config_manager.config.documentation_model,
                    "chat": ai_config_manager.config.chat_model
                }
            }
            
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to get model info: {str(e)}")

    # =====================================
    # END AI ENDPOINTS
    # =====================================

    # AI Documentation Agent endpoints
    @app.post("/api/ai/generate-documentation")
    async def ai_generate_documentation(request: dict):
        """Generate documentation using AI"""
        try:
            ai_agent = sample_agents["ai_documentation_agent"]
            task = {
                "type": "generate_documentation",
                "doc_type": request.get("doc_type", "readme"),
                "content": request.get("content", ""),
                "project_info": request.get("project_info", {})
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI documentation generation error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/ai/analyze-code-for-docs")
    async def ai_analyze_code_for_docs(request: dict):
        """Analyze code to generate documentation using AI"""
        try:
            ai_agent = sample_agents["ai_documentation_agent"]
            task = {
                "type": "analyze_code_for_docs",
                "code": request.get("code", ""),
                "language": request.get("language", "python")
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI code analysis for docs error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    # AI Testing Agent endpoints
    @app.post("/api/ai/generate-tests")
    async def ai_generate_tests(request: dict):
        """Generate test suite using AI"""
        try:
            ai_agent = sample_agents["ai_testing_agent"]
            task = {
                "type": "generate_tests",
                "code": request.get("code", ""),
                "language": request.get("language", "python"),
                "test_type": request.get("test_type", "unit_tests"),
                "framework": request.get("framework", "")
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI test generation error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/ai/analyze-coverage")
    async def ai_analyze_coverage(request: dict):
        """Analyze test coverage using AI"""
        try:
            ai_agent = sample_agents["ai_testing_agent"]
            task = {
                "type": "analyze_coverage",
                "code": request.get("code", ""),
                "existing_tests": request.get("existing_tests", ""),
                "language": request.get("language", "python")
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI coverage analysis error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    # AI Debugging Agent endpoints
    @app.post("/api/ai/debug-error")
    async def ai_debug_error(request: dict):
        """Debug error using AI"""
        try:
            ai_agent = sample_agents["ai_debugging_agent"]
            task = {
                "type": "debug_error",
                "code": request.get("code", ""),
                "error_message": request.get("error_message", ""),
                "language": request.get("language", "python"),
                "stack_trace": request.get("stack_trace", "")
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI documentation generation error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/ai/fix-bug")
    async def ai_fix_bug(request: dict):
        """Fix bug using AI"""
        try:
            ai_agent = sample_agents["ai_debugging_agent"]
            task = {
                "type": "fix_bug",
                "code": request.get("code", ""),
                "bug_description": request.get("bug_description", ""),
                "language": request.get("language", "python")
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI bug fixing error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/ai/analyze-performance")
    async def ai_analyze_performance(request: dict):
        """Analyze code performance using AI"""
        try:
            ai_agent = sample_agents["ai_debugging_agent"]
            task = {
                "type": "analyze_performance",
                "code": request.get("code", ""),
                "language": request.get("language", "python"),
                "performance_data": request.get("performance_data", {})
            }
            result = await ai_agent.process_task(task)
            return result
        except Exception as e:
            logger.error(f"AI performance analysis error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    # Multi-Agent Collaboration Endpoints

    def get_collab_manager(request: Request):
        if request and hasattr(request.app.state, "collaboration_manager"):
            return request.app.state.collaboration_manager
        raise RuntimeError("collaboration_manager not found in app.state. Ensure the app is created with the correct manager.")

    @app.post("/api/collaboration/orchestrate")
    async def orchestrate_multi_agent_task(request: dict, req: Request):
        try:
            collab_mgr = get_collab_manager(req)
            task_description = request.get("task_description", "")
            context = request.get("context", {})
            template = request.get("template")
            if not task_description:
                raise HTTPException(status_code=400, detail="Task description is required")
            session = await collab_mgr.orchestrate_multi_agent_task(
                task_description=task_description,
                context=context,
                template=template
            )
            return {
                "session_id": session.id,
                "status": session.status.value,
                "main_task": session.main_task,
                "participating_agents": session.participating_agents,
                "total_subtasks": len(session.subtasks),
                "created_at": session.created_at.isoformat()
            }
        except Exception as e:
            logger.error(f"Multi-agent orchestration error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/api/collaboration/status/{session_id}")
    async def get_collaboration_status(session_id: str, req: Request):
        try:
            collab_mgr = get_collab_manager(req)
            status = await collab_mgr.get_collaboration_status(session_id)
            if "error" in status:
                raise HTTPException(status_code=404, detail=status["error"])
            return status
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error getting collaboration status: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/collaboration/{session_id}/stop")
    async def stop_collaboration_session(session_id: str, req: Request):
        try:
            collab_mgr = get_collab_manager(req)
            success = await collab_mgr.stop_collaboration_session(session_id)
            if success:
                return {"status": "ok", "message": "Collaboration session stopped"}
            else:
                raise HTTPException(status_code=404, detail="Session not found")
        except Exception as e:
            logger.error(f"Error stopping collaboration session: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/collaboration/{session_id}/resume")
    async def resume_collaboration_session(session_id: str, req: Request):
        try:
            collab_mgr = get_collab_manager(req)
            success = await collab_mgr.resume_collaboration_session(session_id)
            if success:
                return {"status": "ok", "message": "Collaboration session resumed"}
            else:
                raise HTTPException(status_code=404, detail="Session not found")
        except Exception as e:
            logger.error(f"Error resuming collaboration session: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/collaboration/{session_id}/reassign")
    async def reassign_collaboration_task(session_id: str, new_agent_id: str, req: Request):
        try:
            collab_mgr = get_collab_manager(req)
            session = collab_mgr.get_session(session_id)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")
            result = await collab_mgr.reassign_task(session, new_agent_id)
            return {
                "status": "ok",
                "message": "Task reassigned",
                "session_id": session_id,
                "new_agent_id": new_agent_id
            }
        except Exception as e:
            logger.error(f"Error reassigning task: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.get("/api/collaboration/templates")
    async def get_collaboration_templates(req: Request):
        collab_mgr = get_collab_manager(req)
        templates = list(collab_mgr.collaboration_templates.keys()) if hasattr(collab_mgr, "collaboration_templates") else ["full_development_cycle", "bug_fixing", "documentation"]
        return {"templates": templates}

    @app.get("/api/collaboration/sessions")
    async def list_collaboration_sessions(req: Request):
        collab_mgr = get_collab_manager(req)
        sessions = await collab_mgr.list_active_sessions() if hasattr(collab_mgr, "list_active_sessions") else []
        return {"sessions": sessions}

    # Error handling middleware
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next):
        import time
        start = time.time()
        response = await call_next(request)
        process_time = time.time() - start
        
        # Add custom headers
        response.headers["X-Process-Time"] = str(process_time)
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        
        return response

    return app

# Create FastAPI app with authentication and database services
from core.auth_service import auth_service
from core.database_manager import get_database_manager
app = create_app(auth_service, get_database_manager())

# Export for test patching and imports
from core.agent_collaboration_manager import collaboration_manager
from core.ai_coordinator import get_ai_coordinator
from agents.ai_agents.sample_agents import CodeAnalyzerAgent, DocumentationAgent, TestingAgent
from agents.ai_agents.project_analysis_agent import ProjectAnalysisAgent
from agents.ai_agents.intelligent_code_suggestion_engine import IntelligentCodeSuggestionEngine

sample_agents = {
    "code_analyzer": CodeAnalyzerAgent(),
    "documentation_agent": DocumentationAgent(),
    "testing_agent": TestingAgent(),
    "ai_code_generator": CodeGeneratorAgent(),
    "ai_documentation_agent": AIDocumentationAgent(),
    "ai_testing_agent": AITestingAgent(),
    "ai_debugging_agent": AIDebuggingAgent(),
    "ai_project_analyzer": ProjectAnalysisAgent(),
    "ai_code_suggestion_engine": IntelligentCodeSuggestionEngine()
}

# For test patching
__all__ = [
    "app",
    "collaboration_manager",
    "get_ai_coordinator",
    "sample_agents"
]

ai_coordinator = get_ai_coordinator()

import asyncio
async def main():
    print("Results:")
    print("Raft Heartbeats:")
    # Add any other output required by the test here

    def get_agents(request: Request = None):
        if request and hasattr(request.app.state, "sample_agents"):
            return request.app.state.sample_agents
        return sample_agents

    @app.post("/api/ai/analyze-project")
    async def analyze_project(request: dict, req: Request):
        agents = get_agents(req)
        ai_agent = agents["ai_project_analyzer"]
        result = await ai_agent.process_task(request)
        return result

    @app.post("/api/ai/analyze-project-structure")
    async def analyze_project_structure(request: dict, req: Request):
        agents = get_agents(req)
        ai_agent = agents["ai_project_analyzer"]
        result = await ai_agent.process_task(request)
        return result

    @app.post("/api/ai/get-code-suggestions")
    async def get_code_suggestions(request: dict, req: Request):
        agents = get_agents(req)
        ai_agent = agents["ai_code_suggestion_engine"]
        result = await ai_agent.process_task(request)
        return result

    @app.post("/api/ai/complete-code")
    async def complete_code(request: dict, req: Request):
        agents = get_agents(req)
        ai_agent = agents["ai_code_suggestion_engine"]
        result = await ai_agent.process_task(request)
        return result

    return app

# Initialize the application
if __name__ == "__main__":
    import uvicorn
    from core.auth_service import AuthenticationService
    from core.database_manager import DatabaseManager
    
    # Initialize core services
    db_manager = DatabaseManager()
    auth_service = AuthenticationService(db_manager=db_manager)
    
    # Create the FastAPI app
    app = create_app(auth_service, db_manager)
    
    print("🚀 Starting MASS Framework Server...")
    print("📱 Web Interface: http://localhost:8000")
    print("📚 API Documentation: http://localhost:8000/docs")
    print("🔧 Admin Interface: http://localhost:8000/admin")
    
    # Start the server
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        log_level="info",
        reload=False
    )
