﻿#!/bin/bash
set -e

echo "=== MASS Framework Application Setup ==="

# Update system
sudo yum update -y

# Install Python 3.11
sudo yum install -y python3.11 python3.11-pip git

# Create application directory
sudo mkdir -p /opt/mass-framework
sudo chown ec2-user:ec2-user /opt/mass-framework
cd /opt/mass-framework

# Setup Python environment
python3.11 -m venv venv
source venv/bin/activate

# Install requirements
pip install --upgrade pip
pip install -r requirements.txt

# Setup environment variables
cp .env.production .env

# Get RDS endpoint (you'll need to update this manually)
# export DB_HOST="your-rds-endpoint"
# export DB_NAME="mass_framework"
# export DB_USER="massadmin"
# export DB_PASSWORD="MassFramework2024!"

# Initialize database (if needed)
# python main.py --init-db

# Create systemd service
sudo tee /etc/systemd/system/mass-framework.service > /dev/null << 'EOF'
[Unit]
Description=MASS Framework Application
After=network.target

[Service]
Type=simple
User=ec2-user
WorkingDirectory=/opt/mass-framework
Environment=PATH=/opt/mass-framework/venv/bin
ExecStart=/opt/mass-framework/venv/bin/python main.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable mass-framework
sudo systemctl start mass-framework

echo "=== MASS Framework Application Setup Complete ==="
echo "Service status:"
sudo systemctl status mass-framework
